package com.broadleafcommerce.tests;

import com.broadleafcommerce.base.BaseTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.broadleafcommerce.pages.CartPage;
import com.broadleafcommerce.pages.HomePage;
import com.broadleafcommerce.pages.LoginPage;
import com.broadleafcommerce.pages.ProductSearchPage;

public class AddToCartTest extends BaseTest {

	@Test
	public void testAddToCartFromSearch() {
		// Step 1: Login
		LoginPage loginPage = new LoginPage(driver);
		loginPage.openLoginPage();
		loginPage.login("admin.test2407@gmail.com", "Avani@2407"); // use your credentials

		HomePage homePage = new HomePage(driver);
		Assert.assertTrue(homePage.isUserLoggedIn(), "Login failed!");

		// Step 2: Search Product
		ProductSearchPage searchPage = new ProductSearchPage(driver);
		searchPage.searchProduct("shirt");

		new WebDriverWait(driver, Duration.ofSeconds(10))
				.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#products .card")));

// Step 3: Quick View
		CartPage cartPage = new CartPage(driver);
		cartPage.clickFirstProduct();
		cartPage.chooseColor();
		cartPage.chooseSize();
		cartPage.addFirstProductToCart();
		cartPage.viewCart();
		System.out.println("Product added to cart successfully!");

		cartPage.quantityDropdown(10);
		System.out.println("Increase Decrease successfully");
       
    }

}
