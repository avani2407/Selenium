package com.broadleafcommerce.tests;

import com.broadleafcommerce.base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.broadleafcommerce.pages.HomePage;
import com.broadleafcommerce.pages.LoginPage;
import com.broadleafcommerce.pages.ProductSearchPage;

public class SearchTest extends BaseTest {

    @Test
    public void testProductSearch() {
        // Step 1: Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.openLoginPage();
        loginPage.login("admin.test2407@gmail.com", "Avani@2407"); // use your credentials

        HomePage homePage = new HomePage(driver);
        Assert.assertTrue(homePage.isUserLoggedIn(), "Login failed!");

        // Step 2: Search Product
        ProductSearchPage searchPage = new ProductSearchPage(driver);
        searchPage.searchProduct("shirt");

        
        // Assertion (check product page opened)
        String url = driver.getCurrentUrl().toLowerCase();
        Assert.assertTrue(url.contains("shirt"), "Search failed! Actual URL: " + url);
    }
}
