package com.broadleafcommerce.tests;

import com.broadleafcommerce.base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.broadleafcommerce.pages.HomePage;
import com.broadleafcommerce.pages.LoginPage;

public class LoginTest extends BaseTest {

    @Test
    public void testLogin() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.openLoginPage();
        loginPage.login("admin.test2407@gmail.com", "Avani@2407"); // use demo credentials

        HomePage homePage = new HomePage(driver);
        Assert.assertTrue(homePage.isUserLoggedIn(), "Login failed, My Account not displayed!");
    }
}
